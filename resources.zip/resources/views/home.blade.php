@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-new text-light">
                <div class="card-header"><span class="text-uppercase"> upload a song </span></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('songsupload') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="row mb-3">
                            <label for="title" class="col-md-4 col-form-label text-md-end">{{ __('Title') }}</label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control @error('title') is-invalid @enderror" name="title" value="{{ old('title') }}" required autocomplete="title" autofocus>

                                @error('title')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="genre" class="col-md-4 col-form-label text-md-end">{{ __('Genre') }}</label>

                            <div class="col-md-6">

                                <select id="genre" class="form-control @error('genre') is-invalid @enderror" name="genre" value="{{ old('genre') }}" required autocomplete="genre" autofocus>
                                    <option>Select Genre</option>
                                    <option value="afro">Afro Pop</option>
                                    <option value="dancehall">Dance Hall</option>
                                    <option value="gospel">Gospel</option>
                                    <option value="hiphop">Hip Hop</option>
                                    <option value="reggae">Reggae</option>
                                </select>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="song" class="col-md-4 col-form-label text-md-end">{{ __('Song File') }}</label>

                            <div class="col-md-6">
                                <input id="song" type="file" class="form-control @error('song') is-invalid @enderror" name="song" value="{{ old('song') }}" required autocomplete="song" autofocus>

                                @error('song')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="artwork" class="col-md-4 col-form-label text-md-end">{{ __('Artwork') }}</label>

                            <div class="col-md-6">
                                <input id="artwork" type="file" class="form-control @error('artwork') is-invalid @enderror" name="artwork" value="{{ old('artwork') }}" required autocomplete="artwork" autofocus>

                                @error('artwork')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>



                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4 text-center">
                                <button type="submit" class="btn btn-success">
                                    {{ __('Upload') }}
                                </button>
                                <br><br>
                                <span class="text-dark bg-light">{{ session('mssg') }}</span>
                            </div>
                        </div>
                    </form>

                </div>
            </div>

            <br><br>

            <div class="card bg-new text-light">
                <div class="card-header"><span class="text-uppercase"> upload an album </span></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('albumupload') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="row mb-3">
                            <label for="title" class="col-md-4 col-form-label text-md-end">{{ __('Album Title') }}</label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control @error('title') is-invalid @enderror" name="albumtitle" value="{{ old('title') }}" required autocomplete="title" autofocus>

                                @error('title')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="genre" class="col-md-4 col-form-label text-md-end">{{ __('Genre') }}</label>

                            <div class="col-md-6">

                                <select id="genre" class="form-control @error('genre') is-invalid @enderror" name="genre" value="{{ old('genre') }}" required autocomplete="genre" autofocus>
                                    <option>Select Genre</option>
                                    <option value="afro">Afro Pop</option>
                                    <option value="dancehall">Dance Hall</option>
                                    <option value="gospel">Gospel</option>
                                    <option value="hiphop">Hip Hop</option>
                                    <option value="reggae">Reggae</option>
                                </select>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="artwork" class="col-md-4 col-form-label text-md-end">{{ __('Artwork') }}</label>

                            <div class="col-md-6">
                                <input id="artwork" type="file" class="form-control @error('artwork') is-invalid @enderror" name="artwork" value="{{ old('artwork') }}" required autocomplete="artwork" autofocus>

                                @error('artwork')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <br>

                        <div class="row mb-3">
                            <label for="title" class="col-md-4 col-form-label text-md-end">{{ __('Song Title') }}</label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control @error('title') is-invalid @enderror" name="title[]" value="{{ old('title') }}" required autocomplete="title" autofocus>

                                @error('title')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="song" class="col-md-4 col-form-label text-md-end">{{ __('Song File') }}</label>

                            <div class="col-md-6">
                                <input id="song" type="file" class="form-control @error('song') is-invalid @enderror" name="song[]" value="{{ old('song') }}" required autocomplete="song" autofocus>

                                @error('song')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div id="plus">

                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4 text-center">
                                <a  onclick="addField()" class="btn btn-success">
                                    {{ __('Add Another Song') }} <span class="bi bi-plus"></span>
                                </a>
                                <br><br>
                            </div>
                        </div>



                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4 text-center">
                                <button type="submit" class="btn btn-success">
                                    {{ __('Upload') }}
                                </button>
                                <br><br>
                                <span class="text-dark bg-light">{{ session('mssg2') }}</span>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

    function addField(){

        var title = "<div class='row mb-3'><label for='title' class='col-md-4 col-form-label text-md-end'>{{ __('Song Title') }}</label><div class='col-md-6'><input id='title' type='text' class='form-control @error('title') is-invalid @enderror' name='title[]' value='{{ old('title') }}' required autocomplete='title' autofocus>@error('title')<span class='invalid-feedback' role='alert'><strong>{{ $message }}</strong></span>@enderror</div></div>";

        var song = "<div class='row mb-3'><label for='song' class='col-md-4 col-form-label text-md-end'>{{ __('Song File') }}</label><div class='col-md-6'><input id='song' type='file' class='form-control @error('song') is-invalid @enderror' name='song[]' value='{{ old('song') }}' required autocomplete='song' autofocus>@error('song')<span class='invalid-feedback' role='alert'><strong>{{ $message }}</strong></span>@enderror</div></div>";

        $("#plus").append(title + song);
    }
</script>
@endsection
